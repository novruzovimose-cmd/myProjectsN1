import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { finalize } from 'rxjs';
import { LoaderService } from './loader';

export const loaderInterceptor: HttpInterceptorFn = (req, next) => {
  const loader: LoaderService = inject(LoaderService); 
  loader.show();
  return next(req).pipe(finalize(() => loader.hide()));
};