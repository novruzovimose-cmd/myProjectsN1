import { Component } from '@angular/core';
import { Router, RouterLink } from '@angular/router';


@Component({
  selector: 'app-home',
  imports: [RouterLink],
  templateUrl: './home.html',
  styleUrl: './home.css',
})
export class Home {
  imageUrl1:string = `https://i.insider.com/589c8453dd0895a7518b4bef?width=1000&format=jpeg&auto=webp`
  imageUrl2:string = `https://www.cassidytravel.ie/images/main-image---flamingo-las-vegas`
  imageUrl3:string = `https://img.magnific.com/free-photo/aerial-shot-aria-hotel-las-vegas_181624-42881.jpg?semt=ais_hybrid&w=740&q=80`
}
