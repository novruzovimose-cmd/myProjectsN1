import { HttpClient } from '@angular/common/http';
import { Injectable, Signal, signal } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class Xelsawyoebi {

 

  hotels = signal<any[]>([])
    rooms = signal<any[]>([])

    bookRoom(data: any) {
  return this.http.post('https://hotelbooking.stepprojects.ge/api/Booking', data, {
    responseType: 'text',
    headers: { 'Content-Type': 'application/json' }  // 👈 force this
  });
}


   fetchHotels() {
    this.http.get('https://hotelbooking.stepprojects.ge/api/Hotels/GetAll')
      .subscribe({
        next: (res: any) => {
          console.log('FULL HOTELS RESPONSE:', res); // ✅ log everything
          this.hotels.set(res); // later we’ll display with @for
        },
        error: (err) => {
          console.error('Failed to fetch hotels:', err);
        }
      });
  }

  userInfo: BehaviorSubject<any> = new BehaviorSubject(null);
  private apiUrl = 'https://api.everrest.educata.dev/auth'
  constructor(private http: HttpClient, public cookieService: CookieService) {
    
  }
  signUp(data: any) {
    return this.http.post("https://api.everrest.educata.dev/auth/sign_up", data)
  }

  signIn(data:any) {
    return this.http.post("https://api.everrest.educata.dev/auth/sign_in", data)
  }
  getMyInfo() {
  const token = this.cookieService.get('user');
  
  // console.log('TOKEN IN SERVICE:', token); 
  return this.http.get(`https://api.everrest.educata.dev/auth`, {
    headers: { Authorization: `Bearer ${token}` }
  });
}

fetchRooms(hotelId: number) {
    this.http.get(`https://hotelbooking.stepprojects.ge/api/Rooms/GetRoom/${hotelId}`)
      .subscribe({
        next: (res: any) => {
          console.log(`ROOMS FOR HOTEL ${hotelId}:`, res);
          this.rooms.set([res]);
        },
        error: (err) => console.error('Booking failed:', err.error) // 👈 .error shows server's message
      });



      
  }






}
