import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Xelsawyoebi } from '../xelsawyoebi';
import { CookieService } from 'ngx-cookie-service';

interface SignupResponse {
  accessToken: string;
}

@Component({
  selector: 'app-signup',
  imports: [ReactiveFormsModule],
  templateUrl: './signup.html',
  styleUrls: ['./signup.css'],
})
export class Signup {
  formInfo: FormGroup = new FormGroup({
    firstName: new FormControl('', Validators.required),
    lastName: new FormControl('', Validators.required),
    age: new FormControl('', Validators.required),
    email: new FormControl('', [Validators.required, Validators.email]),
    password: new FormControl('', [Validators.required, Validators.minLength(6)]),
    address: new FormControl(''),
    phone: new FormControl('', Validators.required),
    zipcode: new FormControl(''),
    avatar: new FormControl('', Validators.required),
    gender: new FormControl('MALE', Validators.required)
  })
  constructor(private api: Xelsawyoebi, private cookieService: CookieService) {}
   signup() {
    if (this.formInfo.valid) {
      this.api.signUp(this.formInfo.value).subscribe({
        next: (data: any) => {
          console.log('Signup success:', data);
          
          alert("You Signed Up Successfully!")
        },
        error: (err) => {
          console.error('Signup failed:', err);
        }
      });
    }
  }
 }
