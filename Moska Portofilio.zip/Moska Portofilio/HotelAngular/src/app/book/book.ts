import { Component } from '@angular/core';
import { Xelsawyoebi } from '../xelsawyoebi';
import { HttpClient } from '@angular/common/http';
import { Router, RouterLink } from '@angular/router';

@Component({
  selector: 'app-book',
  imports: [RouterLink],
  templateUrl: './book.html',
  styleUrl: './book.css',
})
export class Book {
  hotels: any

  constructor(public api: Xelsawyoebi) {
    this.api.fetchHotels();
      this.hotels = this.api.hotels;
  }

 

}
