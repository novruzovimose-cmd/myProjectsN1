import { TestBed } from '@angular/core/testing';

import { Xelsawyoebi } from './xelsawyoebi';

describe('Xelsawyoebi', () => {
  let service: Xelsawyoebi;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Xelsawyoebi);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
