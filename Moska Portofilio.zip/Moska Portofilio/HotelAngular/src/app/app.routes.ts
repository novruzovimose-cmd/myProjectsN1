import { Routes } from '@angular/router';
import { Home } from './home/home';
import { Book } from './book/book';
import { Dashboard } from './dashboard/dashboard';
import { Login } from './login/login';
import { Signup } from './signup/signup';
import { Profile } from './profile/profile';
import { Notfound } from './notfound/notfound';

export const routes: Routes = [
    {path: '', component: Home},
    {path: 'book', component: Book},
    {path: 'dashboard', component: Dashboard},
    {path: 'login', component: Login},
    {path: 'signup', component: Signup},
    {path: 'profile', component: Profile},
    { path: 'hotel/:id', component: Dashboard },
    {path: '**', component: Notfound}
    
];
