import { Component, inject, NgModule, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Header } from "./header/header";
import { Footer } from "./footer/footer";
import { NgModel, ReactiveFormsModule } from '@angular/forms';
import { loaderInterceptor } from './loader-interceptor';
import { LoaderService } from './loader';



@Component({
  selector: 'app-root',
  imports: [RouterOutlet, Header, Footer, ReactiveFormsModule],
  templateUrl: './app.html',
  styleUrl: './app.css'
})



export class App {
  protected readonly title = signal('sastumro');
  loader = inject(LoaderService)
}
