import { Component, signal } from '@angular/core';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { ReactiveFormsModule } from '@angular/forms';
import { Xelsawyoebi } from '../xelsawyoebi';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './profile.html',
  styleUrls: ['./profile.css']
})
export class Profile {
  userInfo = signal<any | undefined>(undefined);
  loading = signal(true);
  private loaded = false; 

  constructor(
    private api: Xelsawyoebi,
    private cookieService: CookieService,
    private router: Router
  ) {
    const token = this.cookieService.get('user');
    if (!token) {
      this.router.navigate(['/login']);
      return;
    }

    if (!this.loaded) {
      this.loaded = true;
      this.api.getMyInfo().subscribe({
        next: (data: any) => {
          console.log('USER INFO:', data);
          this.userInfo.set(data);
          this.loading.set(false);
        },
        error: (err: any) => {
          console.log('ERROR:', err);
          this.loading.set(false);
        }
      });
    }
  }

  logout() {
    this.cookieService.delete('user');
    this.router.navigate(['/login']);

    

  }
}