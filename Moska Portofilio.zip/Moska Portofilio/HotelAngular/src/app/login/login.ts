import { Component, ElementRef, ViewChild, viewChild } from '@angular/core';
import { FormControl, FormGroup, Validators, ɵInternalFormsSharedModule, ReactiveFormsModule } from '@angular/forms';
import { Xelsawyoebi } from '../xelsawyoebi';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-login',
  imports: [ɵInternalFormsSharedModule, ReactiveFormsModule],
  templateUrl: './login.html',
  styleUrl: './login.css',
})
export class Login {

constructor(public api: Xelsawyoebi,
   public cookieService: CookieService,
    public router: Router
) {}
 

@ViewChild("loginSMS") loginSMS!: ElementRef
formInfo: FormGroup = new FormGroup({
  email: new FormControl('', [Validators.required, Validators.email]),
    password: new FormControl('', [Validators.required, Validators.minLength(6)])
})
 login() {
    if (this.formInfo.valid) {
      this.api.signIn(this.formInfo.value).subscribe({
        next: (data: any) => {
          console.log('FULL DATA:', JSON.stringify(data));
  this.api.userInfo.next(data);
          console.log('LOGIN RESPONSE:', data); 
  this.cookieService.set('user', data.access_token, { path: '/' });
  this.api.userInfo.next(data); 
  setTimeout(() => this.router.navigate(['/profile']), 1500);
         
          if (data.access_token) {
          this.cookieService.set('user', data.access_token, { path: '/' });
    localStorage.setItem('profile', JSON.stringify(data)); 
   
 
          }
          

          this.loginSMS.nativeElement.innerText = "ავტორიზაცია წარმატებულია";
          this.loginSMS.nativeElement.style.color = "darkgreen";

          setTimeout(() => {
            this.router.navigate(['/profile']);
          }, 1500);
        },
        error: (err: any) => {
          console.error('Login failed:', err);
          this.loginSMS.nativeElement.innerText = err.error.error;
          this.loginSMS.nativeElement.style.color = "darkred";
        }
      });
    }
  }







}
