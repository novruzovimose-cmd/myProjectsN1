import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Xelsawyoebi } from '../xelsawyoebi';
import { FormControl, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-dashboard',
  imports: [ReactiveFormsModule],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.css',
})
export class Dashboard {
  rooms: any;
  loggedUserId: number | null = null;
  selectedRoomPrice = 0;

  
 formInfo: FormGroup = new FormGroup({
  checkInDate: new FormControl('', Validators.required),
  checkOutDate: new FormControl('', Validators.required),
  customerName: new FormControl('', Validators.required),
  customerPhone: new FormControl('', Validators.required),
  selectedRoomId: new FormControl(null, Validators.required)
});

  constructor(private route: ActivatedRoute, private api: Xelsawyoebi) {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.api.fetchRooms(id);
    this.rooms = this.api.rooms;

    this.api.getMyInfo().subscribe({
      next: (res: any) => {
        this.loggedUserId = res?.id;
      },
      error: (err) => console.error('Failed to fetch user info:', err)
    });
  }

 book() {
  if (this.formInfo.invalid) {
    console.error('Form invalid');
    return;
  }

  this.api.getMyInfo().subscribe({
    next: (res: any) => {
      const userId = res?.id ?? res?.userId ?? res?._id ?? '';

      const bookingData = {
        id: 0,
        roomID: this.formInfo.value.selectedRoomId,
        checkInDate: new Date(this.formInfo.value.checkInDate).toISOString().split('.')[0] + 'Z',
        checkOutDate: new Date(this.formInfo.value.checkOutDate).toISOString().split('.')[0] + 'Z',
        totalPrice: 0,
        isConfirmed: true,
        customerName: this.formInfo.value.customerName,
        customerId: String(userId),
        customerPhone: this.formInfo.value.customerPhone
      };

      console.log('SENDING PAYLOAD:', JSON.stringify(bookingData));

      this.api.bookRoom(bookingData).subscribe({
        next: (res) => {
          alert("დაჯავშნილია")
          console.log('Booking successful!', res);
          this.formInfo.reset();
        },
        error: (err) => 
          
          {alert("ვერ დაიჯავშნა")
            console.error('Booking failed:', err.error)}
          
      });
    },
    error: (err) => console.error('Could not get user info:', err) 
    
  });
}
  selectRoom(roomId: number) {
  this.formInfo.patchValue({ selectedRoomId: roomId });
  
}
}
