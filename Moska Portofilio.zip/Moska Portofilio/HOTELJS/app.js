let main2 = document.querySelector(".main2")


fetch("https://api.everrest.educata.dev/shop/products/all?page_index=1&page_size=38", {
    method: "GET",
    headers: {
        "accept": '*/*'
    }
})
.then( (respone) => respone.json())
.then( (data) => {
    
    
    data.products.forEach(product => {
        main2.innerHTML += `<div  class="card">
                <img onclick="openProduct('${product._id}')" 
     src="${product.thumbnail.includes(`alta`) ? "https://www.shutterstock.com/image-vector/no-photo-blank-image-icon-260nw-1955339317.jpg" : product.thumbnail }" 
     alt="${product.title}" 
     class="card-img">

                <h3 class="card-title">${product.title}</h3>
                <p class="card-desc">${product.description}</p>
                
                <p class="card-price">
                    Price: ${product.price.current} ${product.price.currency}
                    ${product.price.beforeDiscount ? 
                        `<span class="before">Before: ${product.price.beforeDiscount}</span>` : ""}
                    ${product.price.discountPercentage > 0 ? 
                        `<span class="discount">(${product.price.discountPercentage}% off)</span>` : ""}
                </p>
                
                <p class="card-brand">Brand: ${product.brand}</p>
                <p class="card-category">Category: ${product.category.name}</p>
                <p class="card-rating">Rating: ${product.rating}</p>
                <p class="card-stock">Stock: ${product.stock <= 0 ? "Out of Stock" : `${product.stock}` }</p>
                <p class="card-warranty">Warranty: ${product.warranty} years</p>
                <button onclick="addToCart('${product._id}')"  class="btnAdd">Add To Cart</button>

            </div>`
    });
    
} ) 

function addedToCart() {
    alert("This product was Added to Order list Successfuly")
}
function signAccount() {
    
    window.location.href = "Account/account.html"
}
function profilePage() {
    if(Cookies.get("user")) {
window.location.href = "Account/profile.html"
    }
    else {
        alert("ჯერ დარეგისტრირდით გთხოვთ!")
    }
    
}

function cardDetails() {
    window.location.href = "cardDetails/cardDetails.html"
}
function openProduct(_id) {
    console.log("saving prod:", _id);
    
    sessionStorage.setItem("selectedProductId", _id);
    window.location.href = "cardDetails/cardDetails.html";
}
// data.products.forEach(product => {
//     console.log(product);
// });



function seeCart() {

    window.location.href = "myCart/mycart.html"
}


// function addToCart(productId) {
//   let token = Cookies.get("user")

//   if (!token) {
//     alert("Please log in first!")
//     return
//   }

//   fetch("https://api.everrest.educata.dev/shop/cart/product", {
//     method: "PATCH",
//     headers: {
//       "accept": "application/json",
//       "Content-Type": "application/json",
//       "Authorization": `Bearer ${token}`
//     },
//     body: JSON.stringify({
//       id: productId,
//       quantity: 1
//     })
//   })
//   .then(random => random.json())
//   .then(data => {
//     console.log(data)
    
//     if (data.error) {
//       alert(data.error)
//     } else {
//       alert("Added to cart successfully!")
//     }
//   })
//   .catch(error => console.log("Error:", error))
// }

function addToCart(productId) {
  let token = Cookies.get("user")

  if (!token) {
    alert("Please log in first!")
    return
  }


  fetch("https://api.everrest.educata.dev/shop/cart", {
    method: "GET",
    headers: {
      "accept": "application/json",
      "Authorization": `Bearer ${token}`
    }
  })
  .then(respond => respond.json())
  .then(cartData => {

    
    let method

    if (cartData.error) {
      method = "POST"   
    } else {
      method = "PATCH"  
    }

    
    fetch("https://api.everrest.educata.dev/shop/cart/product", {
      method: method,
      headers: {
        "accept": "application/json",
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`
      },
      body: JSON.stringify({
        id: productId,
        quantity: 1
      })
    })
    .then(respond => respond.json())
    .then(data => {
      if (data.error) {
        alert(data.error)
      } else {
        alert("Added to cart! ")
      }
    })

  })
  .catch(error => console.log("Error:", error))
}


//  fetch("https://api.everrest.educata.dev/shop/cart/product", {
//     method: "PATCH",
//     headers: {
//       "accept": "application/json",
//       "Content-Type": "application/json",
//       "Authorization": `Bearer ${token}`
//     },
//     body: JSON.stringify({
//       id: productId,
//       quantity: 1
//     })
//   })
//   .then(random => random.json())
