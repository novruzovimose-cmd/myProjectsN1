
let producttId = sessionStorage.getItem("selectedProductId");
console.log("Loaded productId:", producttId);

function homePage() {
    
    window.location.href = "/index.html"
}
function profilePage() {
    window.location.href = "profile.html"
}
function profilePage() {
    if(Cookies.get("user")) {
window.location.href = "profile.html"
    }
    else {
        alert("ჯერ დარეგისტრირდით გთხოვთ!")
    }
    
}
function signAccount() {
    
    window.location.href = "/Account/account.html"
}
let productId = sessionStorage.getItem("selectedProductId");

if (productId) {
    fetch(`https://api.everrest.educata.dev/shop/products/id/${productId}`, {
        method: "GET",
        headers: { "accept": "*/*" }
    })
    .then(response => response.json())
    .then(product => {
        console.log(product);
        
        document.querySelector(".details").innerHTML = `
            <img src="${product.thumbnail}" alt="${product.title}">
            <h2>${product.title}</h2>
            <p>${product.description}</p>
            <p>Price: ${product.price.current} ${product.price.currency}</p>
            <p>Brand: ${product.brand}</p>
            <p>Category: ${product.category.name}</p>
            <p>Rating: ${product.rating}</p>
            <p>Stock: ${product.stock <= 0 ? "Out of Stock" : product.stock}</p>
        `;
    });
} else {
    document.querySelector(".details").innerHTML = "<p>No product selected.</p>";
}



















































//fetch