function homePage() {
    
    window.location.href = "/index.html"
}

function register(e) {
    e.preventDefault()
    let formInfo = new FormData(e.target)
    let finalForm = Object.fromEntries(formInfo)

    fetch("https://api.everrest.educata.dev/auth/sign_up", {
        method: "POST",
        headers: {
             accept: "application/json",
            "Content-Type": "application/json"
        },
        body: JSON.stringify(finalForm)
    }) .then( (pasuxi) => pasuxi.json() )
    .then( (data) => {
         if (data.errorKeys) {
                console.log(data.errorKeys);

            } else {
                alert("წარმატებულია, გაიარეთ ვერიფიკაცია!")
            }
        
    } )
}

  function login(e) {
    e.preventDefault()
    let formInfo = new FormData(e.target)
    let finalForm = Object.fromEntries(formInfo)
    console.log(finalForm);
    
    fetch("https://api.everrest.educata.dev/auth/sign_in", {
        method: "POST",
        headers: {
            accept: "*/*",
            "Content-Type": "application/json"
        },
        body: JSON.stringify(finalForm)
    }).then((pasuxi) => pasuxi.json())
        .then((data) => {


            if (data.access_token) {
                alert("warmatebuliaaa");
                Cookies.set("user", data.access_token)
            }
            else {
                alert(data.errorKeys[0]);

            }

           
        })
        .catch((bad) => {
            console.log(bad, "bad request");

        })

}
//fetch

function logOut() {
    Cookies.remove("user")
    window.location.href = "/index.html"
}

function profilePage() {
    window.location.href = "profile.html"
}

let profileCard = document.querySelector(".profileMain")

fetch("https://api.everrest.educata.dev/auth", {
    method: "GET",
    headers: {
        accept: "application/json",
        Authorization: `Bearer ${Cookies.get("user")}`
    }
}).then( (pasuxi) => pasuxi.json() )
.then( data => {
    console.log(data);
    profileCard.innerHTML = `<img src="${data.avatar}" alt="">
        <h2>${data.firstName} ${data.lastName}</h2>
        <h4>${data.phone}</h4>
        <button onclick="logOut()" class="logoutBtn"> Log Out </button> `
} )
function profilePage() {
    if(Cookies.get("user")) {
window.location.href = "profile.html"
    }
    else {
        alert("ჯერ დარეგისტრირდით გთხოვთ!")
    }
    
}
