function homePage() {
    window.location.href = "/index.html"
}

function getCart() {
  let cartSection = document.querySelector(".cartSection")
  let token = Cookies.get("user")

  if (!token) {
    cartSection.innerHTML = "<p>Please log in first!</p>"
    return
  }

  fetch("https://api.everrest.educata.dev/shop/cart", {
    method: "GET",
    headers: {
      "accept": "application/json",
      "Authorization": `Bearer ${token}`
    }
  })
  .then(random => random.json())
  .then(data => {
    let cartSection = document.querySelector(".cartSection")
    cartSection.innerHTML = ""

    data.products.forEach(item => {
      fetch(`https://api.everrest.educata.dev/shop/products/id/${item.productId}`, {
        method: "GET",
        headers: { "accept": "application/json" }
      })
      .then(random => random.json())
      .then(product => {
        cartSection.innerHTML += `
          <div class="cart-item">
            <img src="${product.thumbnail}" alt="${product.title}" width="100">
            <h3>${product.title}</h3>
            <p>Price: ${item.pricePerQuantity} ${product.price.currency}</p>
            <p>Before Discount: ${item.beforeDiscountPrice}</p>
            <p>Quantity: ${item.quantity}</p>
            <button onclick="decreaseQuantity('${item.productId}', ${item.quantity})">-</button>
<button onclick="increaseQuantity('${item.productId}', ${item.quantity})">+</button>
<button onclick="removeFromCart('${item.productId}')">Remove</button>
          </div>
        `
      })
    })
  })
  .catch(error => console.log("Error:", error))
}

function removeFromCart(productId) {
  let token = Cookies.get("user")

  fetch("https://api.everrest.educata.dev/shop/cart/product", {
    method: "DELETE",
    headers: {
      "accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": `Bearer ${token}`
    },
    body: JSON.stringify({
      id: productId,
      quantity: 1
    })
  })
  .then(random => random.json())
  .then(data => {
    console.log(data)
    if (data.error) {
      alert(data.error)
    } else {
      alert("Removed from cart!")
      getCart()
    }
  })
  .catch(error => console.log("Error:", error))
}

function increaseQuantity(productId, currentQuantity) {
  let token = Cookies.get("user")

  fetch("https://api.everrest.educata.dev/shop/cart/product", {
    method: "PATCH",
    headers: {
      "accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": `Bearer ${token}`
    },
    body: JSON.stringify({
      id: productId,
      quantity: currentQuantity + 1
    })
  })
  .then(respond => respond.json())
  .then(data => {
    if (data.error) {
      alert(data.error)
    } else {
      getCart()
    }
  })
  .catch(error => console.log("Error:", error))
}
function decreaseQuantity(productId, currentQuantity) {
  let token = Cookies.get("user")

  if (currentQuantity === 1) {
    removeFromCart(productId)
    return
  }

  fetch("https://api.everrest.educata.dev/shop/cart/product", {
    method: "PATCH",
    headers: {
      "accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": `Bearer ${token}`
    },
    body: JSON.stringify({
      id: productId,
      quantity: currentQuantity - 1
    })
  })
  .then(respond => respond.json())
  .then(data => {
    if (data.error) {
      alert(data.error)
    } else {
      getCart()
    }
  })
  .catch(error => console.log("Error:", error))
}

window.onload = getCart